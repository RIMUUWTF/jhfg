If the above .cmd file does not work, enable UAC in your Windows settings, or try installing vcredist with the link below:

https://aka.ms/vs/17/release/vc_redist.x64.exe